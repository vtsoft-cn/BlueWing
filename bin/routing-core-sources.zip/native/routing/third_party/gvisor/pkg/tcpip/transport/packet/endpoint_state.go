// Copyright 2018 The gVisor Authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package packet

import (
	"context"
	"time"

	"github.com/sagernet/gvisor/pkg/log"
	"github.com/sagernet/gvisor/pkg/tcpip"
	"github.com/sagernet/gvisor/pkg/tcpip/stack"
)

// saveReceivedAt is invoked by stateify.
func (p *packet) saveReceivedAt() int64 {
	return p.receivedAt.UnixNano()
}

// loadReceivedAt is invoked by stateify.
func (p *packet) loadReceivedAt(_ context.Context, nsec int64) {
	p.receivedAt = time.Unix(0, nsec)
}

// beforeSave is invoked by stateify.
func (ep *endpoint) beforeSave() {
	ep.rcvMu.Lock()
	ep.rcvDisabled = true
	ep.rcvMu.Unlock()
	ep.stack.RegisterResumableEndpoint(ep)
}

// afterLoad is invoked by stateify.
func (ep *endpoint) afterLoad(ctx context.Context) {
	ep.stack.RegisterRestoredEndpoint(ep)
}

// Restore implements tcpip.RestoredEndpoint.Restore.
func (ep *endpoint) Restore(_ *stack.Stack) {
	ep.mu.Lock()
	defer ep.mu.Unlock()

	ep.ops.InitHandler(ep, ep.stack, tcpip.GetStackSendBufferLimits, tcpip.GetStackReceiveBufferLimits)
	if err := ep.stack.RegisterPacketEndpoint(ep.boundNIC, ep.boundNetProto, ep); err != nil {
		log.Warningf("RegisterPacketEndpoint(%d, %d, _) failed during restore with error: %s", ep.boundNIC, ep.boundNetProto, err)
		return
	}

	ep.rcvMu.Lock()
	ep.rcvDisabled = false
	ep.rcvMu.Unlock()
}

// Resume implements tcpip.ResumableEndpoint.Resume.
func (ep *endpoint) Resume() {
	ep.rcvMu.Lock()
	defer ep.rcvMu.Unlock()
	ep.rcvDisabled = false
}
