package easyconnect

import (
	"bytes"
	"context"
	"crypto/rand"
	"crypto/rsa"
	"crypto/tls"
	"crypto/x509"
	"encoding/hex"
	"encoding/xml"
	"errors"
	"fmt"
	"github.com/mythologyli/zju-connect/internal/bluewing"
	"io"
	"math/big"
	"net"
	"net/http"
	"net/url"
	"os"
	"regexp"
	"runtime"
	"runtime/debug"
	"strconv"
	"strings"
	"time"

	"github.com/mythologyli/zju-connect/log"
	"github.com/pquerna/otp/totp"
	utls "github.com/refraction-networking/utls"
)

var errSMSRequired = errors.New("SMS code required")
var errTOTPRequired = errors.New("TOTP required")
var errCertRequired = errors.New("cert required")
var errNotFound = errors.New("not found")

func (c *Client) requestTwfID(graphCodeFile string) error {
	err := c.loginAuthAndPsw(graphCodeFile)
	if err != nil {
		if errors.Is(err, errSMSRequired) {
			err = c.loginSMS()
			if err != nil {
				return err
			}
		} else if errors.Is(err, errTOTPRequired) {
			err = c.loginTOTP()
			if err != nil {
				return err
			}
		} else if errors.Is(err, errCertRequired) {
			err = c.loginCert()
			if err != nil {
				return err
			}
		} else {
			return err
		}
	}

	return nil
}

func (c *Client) loginAuthAndPsw(graphCodeFile string) error {
	// First we request the TwfID from server
	addr := "https://" + c.server + "/por/login_auth.csp?apiversion=1"
	log.Printf("Request: %s", addr)

	req, err := http.NewRequestWithContext(c.lifecycleCtx, http.MethodGet, addr, nil)
	if err != nil {
		return err
	}
	resp, err := c.httpClient.Do(req)
	if err != nil {
		debug.PrintStack()
		return err
	}

	defer func(Body io.ReadCloser) {
		_ = Body.Close()
	}(resp.Body)

	var buf bytes.Buffer
	_, err = io.Copy(&buf, resp.Body)
	if err != nil {
		return err
	}

	log.DebugPrintln("Response:", buf.String())

	vpnMatch := regexp.MustCompile(`<VPNVERSION>(.*)</VPNVERSION>`).FindSubmatch(buf.Bytes())
	if vpnMatch != nil {
		log.Printf("VPN server version: %s", string(vpnMatch[1]))
	}

	c.twfID = string(regexp.MustCompile(`<TwfID>(.*)</TwfID>`).FindSubmatch(buf.Bytes())[1])
	log.Printf("TWFID: %s", c.twfID)

	rsaKey := string(regexp.MustCompile(`<RSA_ENCRYPT_KEY>(.*)</RSA_ENCRYPT_KEY>`).FindSubmatch(buf.Bytes())[1])
	log.Printf("RSA key: %s", rsaKey)

	rsaExpMatch := regexp.MustCompile(`<RSA_ENCRYPT_EXP>(.*)</RSA_ENCRYPT_EXP>`).FindSubmatch(buf.Bytes())
	rsaExp := ""
	if rsaExpMatch != nil {
		rsaExp = string(rsaExpMatch[1])
	} else {
		log.Printf("Warning: No RSA_ENCRYPT_EXP, using default")
		rsaExp = "65537"
	}
	log.Printf("RSA exp: %s", rsaExp)

	csrfMatch := regexp.MustCompile(`<CSRF_RAND_CODE>(.*)</CSRF_RAND_CODE>`).FindSubmatch(buf.Bytes())
	csrfCode := ""
	password := c.password
	if csrfMatch != nil {
		csrfCode = string(csrfMatch[1])
		log.Printf("CSRF Code: %s", csrfCode)
		password += "_" + csrfCode
	} else {
		log.Printf("Warning: No CSRF rand code")
	}

	pubKey := rsa.PublicKey{}
	pubKey.E, _ = strconv.Atoi(rsaExp)
	modulus := big.Int{}
	modulus.SetString(rsaKey, 16)
	pubKey.N = &modulus

	encryptedPassword, err := rsa.EncryptPKCS1v15(rand.Reader, &pubKey, []byte(password))
	if err != nil {
		return err
	}
	encryptedPasswordHex := hex.EncodeToString(encryptedPassword)

	rndImgMatch := regexp.MustCompile(`<RndImg>(.*)</RndImg>`).FindSubmatch(buf.Bytes())[1]
	rndImg := "0"
	if rndImgMatch != nil {
		rndImg = string(rndImgMatch)
	}

	randCode := ""
	if rndImg == "1" {
		if graphCodeFile != "" || bluewing.Enabled() {
			addr = "https://" + c.server + "/por/rand_code.csp?apiversion=1"
			log.Printf("Request: %s", addr)
			req, err := http.NewRequestWithContext(c.lifecycleCtx, http.MethodGet, addr, nil)
			if err != nil {
				return err
			}
			req.Header.Set("Cookie", "TWFID="+c.twfID)
			req.Header.Set("User-Agent", "EasyConnect_windows")

			resp, err = c.httpClient.Do(req)
			if err != nil {
				return err
			}

			buf.Reset()
			_, err = io.Copy(&buf, resp.Body)
			if err != nil {
				return err
			}
			defer func(Body io.ReadCloser) {
				_ = Body.Close()
			}(resp.Body)

			if bluewing.Enabled() {
				randCode, err = bluewing.Request("image", "请输入图片验证码", buf.Bytes())
				if err != nil {
					return err
				}
			} else {
				if writeErr := os.WriteFile(graphCodeFile, buf.Bytes(), 0644); writeErr != nil {
					log.Printf("Warning: failed to write graph code image to %s: %v", graphCodeFile, writeErr)
				} else {
					log.Printf("Graph check code saved to %s", graphCodeFile)
				}

				fmt.Print("Please enter rand code: ")
				_, err = fmt.Scanln(&randCode)
				if err != nil {
					return err
				}
			}
		} else {
			log.Print("Warning: rand code required, but no graph code file provided.")
		}
	}

	addr = "https://" + c.server + "/por/login_psw.csp?anti_replay=1&encrypt=1&type=cs"
	log.Printf("Request: %s", addr)

	form := url.Values{
		"svpn_rand_code":    {randCode},
		"mitm":              {""},
		"svpn_req_randcode": {csrfCode},
		"svpn_name":         {c.username},
		"svpn_password":     {encryptedPasswordHex},
	}

	req, err = http.NewRequestWithContext(c.lifecycleCtx, http.MethodPost, addr, strings.NewReader(form.Encode()))
	if err != nil {
		return err
	}
	req.Header.Set("Cookie", "TWFID="+c.twfID)
	req.Header.Set("User-Agent", "EasyConnect_windows")

	resp, err = c.httpClient.Do(req)
	if err != nil {
		return err
	}

	buf.Reset()
	_, err = io.Copy(&buf, resp.Body)
	if err != nil {
		return err
	}
	defer func(Body io.ReadCloser) {
		_ = Body.Close()
	}(resp.Body)

	if strings.Contains(buf.String(), "<NextService>auth/sms</NextService>") || strings.Contains(buf.String(), "<NextAuth>2</NextAuth>") {
		log.Print("SMS code required")

		return errSMSRequired
	}

	if strings.Contains(buf.String(), "<NextService>auth/token</NextService>") || strings.Contains(buf.String(), "<NextAuth>7</NextAuth>") {
		log.Print("TOTP required")

		return errTOTPRequired
	}

	if strings.Contains(buf.String(), "<NextAuth>0</NextAuth>") {
		log.Print("Cert required")

		return errCertRequired
	}

	if strings.Contains(buf.String(), "<NextAuth>-1</NextAuth>") || !strings.Contains(buf.String(), "<NextAuth>") {
		log.Print("No NextAuth found")
	} else {
		return errors.New("Not implemented auth: " + buf.String())
	}

	if !strings.Contains(buf.String(), "<Result>1</Result>") {
		return errors.New("Login failed: " + buf.String())
	}

	twfIDMatch := regexp.MustCompile(`<TwfID>(.*)</TwfID>`).FindSubmatch(buf.Bytes())
	if twfIDMatch != nil {
		c.twfID = string(twfIDMatch[1])
		log.Printf("Update TWFID: %s", c.twfID)
	}

	log.Printf("TWFID has been authorized")

	return nil
}

func (c *Client) loginSMS() error {
	if err := bluewing.ConfirmSMS(); err != nil {
		return err
	}
	addr := "https://" + c.server + "/por/login_sms.csp?apiversion=1"
	log.Printf("SMS request: %s", addr)
	req, err := http.NewRequestWithContext(c.lifecycleCtx, http.MethodPost, addr, nil)
	if err != nil {
		return err
	}
	req.Header.Set("Cookie", "TWFID="+c.twfID)
	req.Header.Set("User-Agent", "EasyConnect_windows")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return err
	}

	var buf bytes.Buffer
	buf.Reset()
	_, err = io.Copy(&buf, resp.Body)
	if err != nil {
		return err
	}
	defer func(Body io.ReadCloser) {
		_ = Body.Close()
	}(resp.Body)

	log.DebugPrintf("SMS request response: %s", buf.String())

	if !strings.Contains(buf.String(), "验证码已发送到您的手机") && !strings.Contains(buf.String(), "请输入验证码：") && !strings.Contains(buf.String(), "<USER_PHONE>") {
		return errors.New("unexpected SMS response: " + buf.String())
	}

	log.Printf("SMS code is sent or still valid")

	smsCode := ""
	_, err = bluewing.Scan("sms", &smsCode)
	if err != nil {
		return err
	}

	addr = "https://" + c.server + "/por/login_sms1.csp?apiversion=1"
	log.Printf("SMS Request: %s", addr)
	form := url.Values{
		"svpn_inputsms": {smsCode},
	}

	req, err = http.NewRequestWithContext(c.lifecycleCtx, http.MethodPost, addr, strings.NewReader(form.Encode()))
	if err != nil {
		return err
	}
	req.Header.Set("Cookie", "TWFID="+c.twfID)
	req.Header.Set("User-Agent", "EasyConnect_windows")

	resp, err = c.httpClient.Do(req)
	if err != nil {
		return err
	}

	buf.Reset()
	_, err = io.Copy(&buf, resp.Body)
	if err != nil {
		return err
	}
	defer func(Body io.ReadCloser) {
		_ = Body.Close()
	}(resp.Body)

	log.DebugPrintf("SMS verification response: %s", buf.String())

	if !strings.Contains(buf.String(), "Auth sms suc") && !strings.Contains(buf.String(), "欢迎访问") {
		debug.PrintStack()
		return errors.New("SMS code verification failed: " + buf.String())
	}

	twfIDMatch := regexp.MustCompile(`<TwfID>(.*)</TwfID>`).FindSubmatch(buf.Bytes())
	if twfIDMatch != nil {
		c.twfID = string(twfIDMatch[1])
		log.Printf("Update TWFID: %s", c.twfID)
	}
	log.Print("SMS code verification success")

	return nil
}

func (c *Client) loginTOTP() error {
	var totpCode string
	var err error
	if c.totpSecret == "" {

		_, err = bluewing.Scan("otp", &totpCode)
	} else {
		totpCode, err = totp.GenerateCode(c.totpSecret, time.Now())

	}
	if err != nil {
		return err
	}

	addr := "https://" + c.server + "/por/login_token.csp"
	log.Printf("TOTP Request: %s", addr)
	form := url.Values{
		"svpn_inputtoken": {totpCode},
	}
	req, err := http.NewRequestWithContext(c.lifecycleCtx, http.MethodPost, addr, strings.NewReader(form.Encode()))
	if err != nil {
		return err
	}
	req.Header.Set("Cookie", "TWFID="+c.twfID)
	req.Header.Set("User-Agent", "EasyConnect_windows")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return err
	}

	var buf bytes.Buffer
	buf.Reset()
	_, err = io.Copy(&buf, resp.Body)
	if err != nil {
		return err
	}
	defer func(Body io.ReadCloser) {
		_ = Body.Close()
	}(resp.Body)

	if !strings.Contains(buf.String(), "Totp auth succ") {
		debug.PrintStack()
		return errors.New("TOTP verification failed: " + buf.String())
	}

	c.twfID = string(regexp.MustCompile(`<TwfID>(.*)</TwfID>`).FindSubmatch(buf.Bytes())[1])
	log.Print("TOTP verification success")

	return nil
}

func (c *Client) loginCert() error {
	addr := "https://" + c.server + "/com/server.crt"
	log.Printf("Get server cert: %s", addr)
	req, err := http.NewRequestWithContext(c.lifecycleCtx, http.MethodPost, addr, nil)
	if err != nil {
		return err
	}
	req.Header.Set("Cookie", "TWFID="+c.twfID)
	req.Header.Set("User-Agent", "EasyConnect_windows")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return err
	}

	var buf bytes.Buffer
	buf.Reset()
	_, err = io.Copy(&buf, resp.Body)
	if err != nil {
		return err
	}
	defer func(Body io.ReadCloser) {
		_ = Body.Close()
	}(resp.Body)

	caCertPool := x509.NewCertPool()
	ok := caCertPool.AppendCertsFromPEM(buf.Bytes())
	if !ok {
		return errors.New("failed to parse server certificate")
	}

	c.setHTTPTransport(&tls.Config{
		InsecureSkipVerify: true,
		Renegotiation:      tls.RenegotiateOnceAsClient,
		Certificates:       []tls.Certificate{c.tlsCert},
		RootCAs:            caCertPool,
	})

	addr = "https://" + c.server + "/por/login_cert.csp?anti_replay=1&encrypt=1&type=cs"
	log.Printf("Cert Request: %s", addr)
	req, err = http.NewRequestWithContext(c.lifecycleCtx, http.MethodPost, addr, nil)
	if err != nil {
		return err
	}
	req.Header.Set("Cookie", "TWFID="+c.twfID)
	req.Header.Set("User-Agent", "EasyConnect_windows")

	resp, err = c.httpClient.Do(req)
	if err != nil {
		return err
	}

	buf.Reset()
	_, err = io.Copy(&buf, resp.Body)
	if err != nil {
		return err
	}
	defer func(Body io.ReadCloser) {
		_ = Body.Close()
	}(resp.Body)

	response := buf.String()
	certSuccess := strings.Contains(response, "<Result>1</Result>") ||
		strings.Contains(response, "Login successfully") ||
		strings.Contains(response, "Auth cert suc")
	if !certSuccess {
		debug.PrintStack()
		return errors.New("Cert verification failed: " + response)
	}

	twfIDMatch := regexp.MustCompile(`<TwfID>(.*)</TwfID>`).FindSubmatch(buf.Bytes())
	if twfIDMatch != nil {
		c.twfID = string(twfIDMatch[1])
		log.Printf("Update TWFID: %s", c.twfID)
	}

	if strings.Contains(response, "<pwpErrorCode>16</pwpErrorCode>") {
		log.Print("Cert verification success (server returned pwpErrorCode=16, profile redirect ignored)")
	} else {
		log.Print("Cert verification success")
	}

	return nil
}

func (c *Client) requestConfig() (string, error) {
	addr := "https://" + c.server + "/por/conf.csp"
	log.Printf("Request: %s", addr)

	req, err := http.NewRequestWithContext(c.lifecycleCtx, http.MethodGet, addr, nil)
	if err != nil {
		return "", err
	}
	req.Header.Set("Cookie", "TWFID="+c.twfID)

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return "", err
	}

	var buf bytes.Buffer
	_, err = io.Copy(&buf, resp.Body)
	if err != nil {
		return "", err
	}
	defer func(Body io.ReadCloser) {
		_ = Body.Close()
	}(resp.Body)

	return buf.String(), nil
}

// requestUpdateSession pings /por/update_session.csp to keep the server-side
// session alive. The official EasyConnect client calls this periodically;
// without it, sangfor servers with strict idle policies (e.g. HUST) close
// the session, which the tunnel layer surfaces as a "broken pipe" →
// "unexpected handshake reply" kick cascade.
func (c *Client) requestUpdateSession(ctx context.Context) error {
	u := url.URL{
		Scheme: "https",
		Host:   c.server,
		Path:   "/por/update_session.csp",
	}
	q := url.Values{}
	q.Set("twfid", c.twfID)
	q.Set("apiversion", "1")
	u.RawQuery = q.Encode()

	req, err := http.NewRequestWithContext(ctx, "GET", u.String(), nil)
	if err != nil {
		return err
	}
	req.Header.Set("Cookie", "TWFID="+c.twfID)
	req.Header.Set("User-Agent", "EasyConnect_Linux_Ubuntu")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return err
	}
	defer func(Body io.ReadCloser) {
		_ = Body.Close()
	}(resp.Body)

	if resp.StatusCode != http.StatusOK {
		if resp.StatusCode == http.StatusNotFound {
			return errNotFound
		}
		return fmt.Errorf("update_session: unexpected status %d", resp.StatusCode)
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return err
	}

	// Successful body looks like:
	//   <Auth><Message>success</Message><ErrorCode>1</ErrorCode><TwfID>...</TwfID></Auth>
	var reply struct {
		Message   string `xml:"Message"`
		ErrorCode string `xml:"ErrorCode"`
	}
	if err := xml.Unmarshal(body, &reply); err != nil {
		return fmt.Errorf("update_session: parse reply: %w", err)
	}
	if reply.Message != "success" || reply.ErrorCode != "1" {
		return fmt.Errorf("update_session: unexpected reply message=%q error_code=%q", reply.Message, reply.ErrorCode)
	}
	return nil
}

func (c *Client) requestResources() (string, error) {
	addr := "https://" + c.server + "/por/rclist.csp"
	log.Printf("Request: %s", addr)

	req, err := http.NewRequestWithContext(c.lifecycleCtx, http.MethodGet, addr, nil)
	if err != nil {
		return "", err
	}
	req.Header.Set("Cookie", "TWFID="+c.twfID)

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return "", err
	}

	var buf bytes.Buffer
	_, err = io.Copy(&buf, resp.Body)
	if err != nil {
		return "", err
	}
	defer func(Body io.ReadCloser) {
		_ = Body.Close()
	}(resp.Body)

	return buf.String(), nil
}

func (c *Client) requestToken() error {
	ctx, cancel := c.rawRequestContext()
	defer cancel()
	dialConn, err := c.dialContext(ctx, "tcp", c.server)
	if err != nil {
		return err
	}
	defer func(dialConn net.Conn) {
		_ = dialConn.Close()
	}(dialConn)
	tlsConfig := &utls.Config{InsecureSkipVerify: true, KeyLogWriter: c.tlsKeyLogWriter}
	if bluewing.Enabled() {
		tlsConfig = bluewing.UTLS(c.server)
	}
	conn := utls.UClient(dialConn, tlsConfig, utls.HelloGolang)
	defer func(conn *utls.UConn) {
		_ = conn.Close()
	}(conn)
	clearDeadline, err := armConnectionContext(ctx, conn)
	if err != nil {
		return err
	}
	defer clearDeadline()
	if err := conn.HandshakeContext(ctx); err != nil {
		return err
	}

	// When establish an HTTPS connection to server and send a valid request with TWFID to it
	// The **TLS ServerHello SessionId** is the first part of token
	log.Printf("ECAgent request: /por/conf.csp & /por/rclist.csp")
	_, err = io.WriteString(
		conn,
		"GET /por/conf.csp HTTP/1.1\r\nHost: "+c.server+
			"\r\nCookie: TWFID="+c.twfID+
			"\r\n\r\nGET /por/rclist.csp HTTP/1.1\r\nHost: "+c.server+
			"\r\nCookie: TWFID="+c.twfID+"\r\n\r\n",
	)
	if err != nil {
		return err
	}

	sessionID := hex.EncodeToString(conn.HandshakeState.ServerHello.SessionId)
	log.Printf("Server session ID: %s", sessionID)

	buf := make([]byte, 8)
	n, err := conn.Read(buf)
	if n == 0 || err != nil {
		return fmt.Errorf("ECAgent request invalid: read %d bytes: %w", n, err)
	}

	c.token = (*[48]byte)([]byte(sessionID[:31] + "\x00" + c.twfID))

	log.Printf("Token: %s", hex.EncodeToString(c.token[:]))

	return nil
}

func (c *Client) requestIP() error {
	ctx, cancel := c.rawRequestContext()
	defer cancel()
	conn, err := c.tlsConn(ctx)
	if err != nil {
		return err
	}
	succeeded := false
	defer func() {
		if !succeeded {
			_ = conn.Close()
		}
	}()
	clearDeadline, err := armConnectionContext(ctx, conn)
	if err != nil {
		return err
	}
	defer clearDeadline()

	// Request IP Packet
	message := []byte{0x00, 0x00, 0x00, 0x00}
	message = append(message, c.token[:]...)
	message = append(message, []byte{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xff, 0xff, 0xff, 0xff}...)

	n, err := conn.Write(message)
	if err != nil {
		return err
	}

	log.DebugPrintf("Request IP: wrote %d bytes", n)
	log.DebugDumpHex(message[:n])

	reply := make([]byte, 0x80)
	n, err = conn.Read(reply)
	if err != nil {
		return err
	}

	log.DebugPrintf("Request IP: read %d bytes", n)
	log.DebugDumpHex(reply[:n])

	if reply[0] != 0x00 {
		return errors.New("unexpected request IP reply")
	}

	c.ip = reply[4:8]
	c.ipReverse = []byte{c.ip[3], c.ip[2], c.ip[1], c.ip[0]}
	if c.underlayDialer != nil {
		c.underlayDialer.ExcludeIP(c.ip)
	}

	log.Printf("Client IP: %s", c.ip.String())

	// Request IP conn CAN NOT be closed, otherwise tx/rx handshake will fail
	c.setRequestIPConn(conn)
	succeeded = true

	return nil
}

func (c *Client) setRequestIPConn(conn net.Conn) {
	c.requestIPConnMu.Lock()
	if c.requestIPConn != nil {
		_ = c.requestIPConn.Close()
	}
	c.requestIPConn = conn
	c.requestIPConnMu.Unlock()

	c.requestIPKeepAlive.Do(func() {
		go c.requestIPKeepAliveLoop()
	})
}

func (c *Client) requestIPKeepAliveLoop() {
	ticker := time.NewTicker(10 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-c.lifecycleCtx.Done():
			return
		case <-ticker.C:
			c.requestIPConnMu.Lock()
			conn := c.requestIPConn
			c.requestIPConnMu.Unlock()
			runtime.KeepAlive(conn)
		}
	}
}
