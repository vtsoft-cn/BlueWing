package auth

import (
	"bytes"
	"encoding/json"
	"fmt"
	"github.com/mythologyli/zju-connect/internal/bluewing"
	"io"
	"net/http"

	"github.com/mythologyli/zju-connect/log"
)

type SMSLogin struct {
	Phone         string
	Domain        string
	GraphCodeFile string
}

func (m SMSLogin) AuthType() string {
	return "auth/smsCheckCode"
}

func (m SMSLogin) LoginDomain() string {
	return m.Domain
}

func (m SMSLogin) login(s *Session, _ AuthInfo) error {
	if err := s.loginAuthSmsCheckCode(m.Phone, m.Domain, m.GraphCodeFile); err != nil {
		return err
	}
	s.username = smsUsername(m.Phone, m.Domain)
	return nil
}

func smsUsername(phone, domain string) string {
	return phone + "@" + domain
}

func (s *Session) loginAuthSmsCheckCode(phone, loginDomain, graphCodeFile string) error {
	if err := bluewing.ConfirmSMS(); err != nil {
		return err
	}
	sendSmsProcess := func(graphCheckCode string) (int, error) {
		return s.sendSms(phone, loginDomain, graphCheckCode)
	}
	err := s.withGraphCheckCode(sendSmsProcess, graphCodeFile)
	if err != nil {
		return err
	}

	code := ""
	log.Print("Please enter the SMS verification code: ")
	_, err = bluewing.Scan("sms", &code)
	if err != nil {
		return err
	}

	smsCheckCodeProcess := func(graphCheckCode string) (int, error) {
		return s.smsCheckCodeImpl(code, phone, loginDomain, graphCheckCode)
	}
	return s.withGraphCheckCode(smsCheckCodeProcess, graphCodeFile)
}

func (s *Session) sendSms(phone, loginDomain, graphCheckCode string) (int, error) {
	log.Println("Perform POST /passport/v1/public/sendSms")

	data := map[string]interface{}{
		"phone":          phone + "@" + loginDomain,
		"graphCheckCode": graphCheckCode,
	}

	postBody, _ := json.Marshal(data)

	u := s.baseURL + "/passport/v1/public/sendSms"
	req, _ := http.NewRequest("POST", u+"?"+WithSharedParams(nil).Encode(), bytes.NewReader(postBody))
	req.Header.Set("User-Agent", UserAgent)
	req.Header.Set("Content-Type", "application/json;charset=utf-8")
	req.Header.Set("x-csrf-token", s.csrfToken)
	req.Header.Set("x-sdp-env", s.env)
	req.Header.Set("x-sdp-traceid", s.randSdpId())

	resp, err := s.client.Do(req)
	if err != nil {
		return 0, err
	}
	defer func(Body io.ReadCloser) {
		_ = Body.Close()
	}(resp.Body)
	body, _ := io.ReadAll(resp.Body)
	log.DebugPrintf("Received sendSms: %s", string(body))

	var re struct {
		Code    int    `json:"code"`
		Message string `json:"message"`
		Data    struct {
			Tips                 string `json:"tips"`
			Interval             string `json:"interval"`
			GraphCheckCodeEnable int    `json:"graphCheckCodeEnable"`
		} `json:"data"`
	}
	err = json.Unmarshal(body, &re)
	if err != nil {
		return 0, err
	}
	log.DebugPrintf("Parsed sendSms: %+v", re)
	if re.Code != 0 {
		if re.Data.GraphCheckCodeEnable == 1 {
			return re.Data.GraphCheckCodeEnable, nil
		}
		return 0, fmt.Errorf("sendSms failed with code %d: %s", re.Code, re.Message)
	}

	return re.Data.GraphCheckCodeEnable, nil
}

func (s *Session) smsCheckCodeImpl(code, phone, loginDomain, graphCheckCode string) (int, error) {
	log.Println("Perform POST /passport/v1/auth/smsCheckCode")

	data := map[string]interface{}{
		"code":  code,
		"phone": phone + "@" + loginDomain,
	}

	if graphCheckCode != "" {
		data["graphCheckCode"] = graphCheckCode
	}
	postBody, _ := json.Marshal(data)

	u := s.baseURL + "/passport/v1/auth/smsCheckCode"
	req, _ := http.NewRequest("POST", u+"?"+WithSharedParams(nil).Encode(), bytes.NewReader(postBody))
	req.Header.Set("User-Agent", UserAgent)
	req.Header.Set("Content-Type", "application/json;charset=utf-8")
	req.Header.Set("x-csrf-token", s.csrfToken)
	req.Header.Set("x-sdp-env", s.env)
	req.Header.Set("x-sdp-traceid", s.randSdpId())

	resp, err := s.client.Do(req)
	if err != nil {
		return 0, err
	}
	defer func(Body io.ReadCloser) {
		_ = Body.Close()
	}(resp.Body)
	body, _ := io.ReadAll(resp.Body)
	log.DebugPrintf("Received smsCheckCode: %s", string(body))

	var re struct {
		Code    int    `json:"code"`
		Message string `json:"message"`
		Data    struct {
			Ticket               string `json:"ticket"`
			GraphCheckCodeEnable int    `json:"graphCheckCodeEnable"`
		} `json:"data"`
	}
	err = json.Unmarshal(body, &re)
	if err != nil {
		return 0, err
	}
	if re.Code != 0 {
		if re.Data.GraphCheckCodeEnable == 1 {
			return re.Data.GraphCheckCodeEnable, nil
		}
		return 0, fmt.Errorf("SMS authentication failed with code %d: %s", re.Code, re.Message)
	}
	log.DebugPrintf("Parsed smsCheckCode: %+v", re)

	if re.Data.Ticket == "" && re.Data.GraphCheckCodeEnable == 0 {
		return 0, fmt.Errorf("SMS authentication succeeded without a ticket")
	}
	s.ticket = re.Data.Ticket

	return re.Data.GraphCheckCodeEnable, nil
}
