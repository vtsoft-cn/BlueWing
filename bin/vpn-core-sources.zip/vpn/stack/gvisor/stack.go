package gvisor

import (
	"context"
	"errors"
	"io"
	"net"
	"os"
	"sync"

	clientpkg "github.com/mythologyli/zju-connect/client"
	"github.com/mythologyli/zju-connect/client/easyconnect"
	"github.com/mythologyli/zju-connect/internal/hook_func"
	"github.com/mythologyli/zju-connect/internal/ippool"
	"github.com/mythologyli/zju-connect/internal/zcdns"
	"github.com/mythologyli/zju-connect/log"
	"gvisor.dev/gvisor/pkg/buffer"
	"gvisor.dev/gvisor/pkg/tcpip"
	"gvisor.dev/gvisor/pkg/tcpip/header"
	"gvisor.dev/gvisor/pkg/tcpip/network/ipv4"
	"gvisor.dev/gvisor/pkg/tcpip/stack"
	"gvisor.dev/gvisor/pkg/tcpip/transport/icmp"
	"gvisor.dev/gvisor/pkg/tcpip/transport/tcp"
	"gvisor.dev/gvisor/pkg/tcpip/transport/udp"
)

type Stack struct {
	bridgeMu     sync.Mutex
	bridgeClosed bool
	gvisorStack  *stack.Stack
	resolve      zcdns.LocalServer
	ipPool       *ippool.IPPool[[]clientpkg.DomainResource]

	endpoint *Endpoint
	ipMu     sync.Mutex
	ip       tcpip.Address
	packets  *packetLink
	sources  map[tcpip.Address]bool
}

const NICID tcpip.NICID = 1
const MTU uint32 = 1400
const maxInboundPacketSize = 1500

type Endpoint struct {
	onFailure func()
	client    clientpkg.Client

	l3Conn io.ReadWriteCloser

	dispatcher stack.NetworkDispatcher
}

func (ep *Endpoint) ParseHeader(*stack.PacketBuffer) bool {
	return true
}

func (ep *Endpoint) MTU() uint32 {
	return MTU
}

func (ep *Endpoint) SetMTU(mtu uint32) {
	log.Printf("don't support change MTU from %d to %d", MTU, mtu)
}

func (ep *Endpoint) MaxHeaderLength() uint16 {
	return 0
}

func (ep *Endpoint) LinkAddress() tcpip.LinkAddress {
	return ""
}

func (ep *Endpoint) SetLinkAddress(addr tcpip.LinkAddress) {}

func (ep *Endpoint) Capabilities() stack.LinkEndpointCapabilities {
	return stack.CapabilityNone
}

func (ep *Endpoint) Attach(dispatcher stack.NetworkDispatcher) {
	ep.dispatcher = dispatcher
}

func (ep *Endpoint) IsAttached() bool {
	return ep.dispatcher != nil
}

func (ep *Endpoint) Wait() {}

func (ep *Endpoint) ARPHardwareType() header.ARPHardwareType {
	return header.ARPHardwareNone
}

func (ep *Endpoint) AddHeader(*stack.PacketBuffer) {}

func (ep *Endpoint) Close() {}

func (ep *Endpoint) SetOnCloseAction(func()) {}

// WritePackets is called when get packets from gVisor stack. Then it sends them to VPN server
func (ep *Endpoint) WritePackets(list stack.PacketBufferList) (int, tcpip.Error) {
	for _, packetBuffer := range list.AsSlice() {
		buf := joinPacketSlices(packetBuffer.AsSlices())

		if ep.l3Conn != nil {
			n, err := ep.l3Conn.Write(buf)
			if err != nil {
				if ep.onFailure != nil {
					go ep.onFailure()
					return 0, &tcpip.ErrAborted{}
				}
				if errors.Is(err, clientpkg.ErrResourceNotFound) {
					log.Printf("%v", err)
					continue
				}

				// Server-initiated SHUTDOWN: known terminal state from
				// sangfor (cmd 0x08). No point retrying; run the registered
				// cleanup hooks (DNS revert, tun device close, etc.) and
				// exit so systemd / a wrapper can do a fresh login. This
				// is strictly better than panicking with a gvisor stack
				// trace, which obscures the actual cause.
				if errors.Is(err, easyconnect.ErrSangforShutdown) {
					log.Printf("WritePackets: server SHUTDOWN; running cleanup hooks and exiting for clean restart")
					if !hook_func.IsTerminal() {
						hook_func.ExecTerminalFunc(context.Background())
					}
					os.Exit(2)
				}

				if hook_func.IsTerminal() {
					return list.Len(), nil
				} else {
					panic(err)
				}
			}
			log.DebugPrintf("Send: wrote %d bytes", n)
			log.DebugDumpHex(buf[:n])
		}
	}

	return list.Len(), nil
}

func joinPacketSlices(slices [][]byte) []byte {
	total := 0
	for _, slice := range slices {
		total += len(slice)
	}
	buf := make([]byte, total)
	offset := 0
	for _, slice := range slices {
		offset += copy(buf[offset:], slice)
	}
	return buf
}

func NewStack(client clientpkg.Client) (*Stack, error) {
	s := &Stack{}

	s.gvisorStack = stack.New(stack.Options{
		NetworkProtocols:   []stack.NetworkProtocolFactory{ipv4.NewProtocol},
		TransportProtocols: []stack.TransportProtocolFactory{tcp.NewProtocol, udp.NewProtocol, icmp.NewProtocol4},
		HandleLocal:        true,
	})

	s.endpoint = &Endpoint{
		client: client,
	}

	tcpipErr := s.gvisorStack.CreateNICWithOptions(NICID, s.endpoint, stack.NICOptions{Name: "bluewing-vpn"})
	if tcpipErr != nil {
		return nil, errors.New(tcpipErr.String())
	}

	ip, err := client.IP()
	if err != nil {
		return nil, err
	}
	ip = ip.To4()
	if ip == nil {
		return nil, errors.New("VPN address is not IPv4")
	}

	addr := tcpip.AddrFromSlice(ip)
	s.ip = addr
	protoAddr := tcpip.ProtocolAddress{
		AddressWithPrefix: tcpip.AddressWithPrefix{
			Address:   addr,
			PrefixLen: 32,
		},
		Protocol: ipv4.ProtocolNumber,
	}

	tcpipErr = s.gvisorStack.AddProtocolAddress(NICID, protoAddr, stack.AddressProperties{})
	if tcpipErr != nil {
		return nil, errors.New(tcpipErr.String())
	}
	clientpkg.RegisterIPUpdateHandler(client, s.updateIP)

	sOpt := tcpip.TCPSACKEnabled(true)
	s.gvisorStack.SetTransportProtocolOption(tcp.ProtocolNumber, &sOpt)
	cOpt := tcpip.CongestionControlOption("cubic")
	s.gvisorStack.SetTransportProtocolOption(tcp.ProtocolNumber, &cOpt)
	s.gvisorStack.AddRoute(tcpip.Route{Destination: header.IPv4EmptySubnet, NIC: NICID})

	return s, nil
}

func (s *Stack) updateIP(ip net.IP) error {
	ip = ip.To4()
	if ip == nil {
		return errors.New("virtual IP update is not IPv4")
	}
	newAddr := tcpip.AddrFromSlice(ip)
	s.ipMu.Lock()
	defer s.ipMu.Unlock()
	if newAddr == s.ip {
		return nil
	}
	protoAddr := tcpip.ProtocolAddress{
		AddressWithPrefix: tcpip.AddressWithPrefix{Address: newAddr, PrefixLen: 32},
		Protocol:          ipv4.ProtocolNumber,
	}
	if err := s.gvisorStack.AddProtocolAddress(NICID, protoAddr, stack.AddressProperties{}); err != nil {
		return errors.New(err.String())
	}
	if err := s.gvisorStack.RemoveAddress(NICID, s.ip); err != nil {
		_ = s.gvisorStack.RemoveAddress(NICID, newAddr)
		return errors.New(err.String())
	}
	s.ip = newAddr
	return nil
}

func (s *Stack) SetupResolve(r zcdns.LocalServer) {
	s.resolve = r
}

func (s *Stack) SetupIPPool(ipPool *ippool.IPPool[[]clientpkg.DomainResource]) {
	s.ipPool = ipPool
}

func (s *Stack) Run() {
	var connErr error
	if s.endpoint.l3Conn == nil {
		s.endpoint.l3Conn, connErr = s.endpoint.client.NewL3Conn()
	}
	if connErr != nil {
		panic(connErr)
	}
	// Read from VPN server and send to gVisor stack
	buf := make([]byte, maxInboundPacketSize)
	for {
		n, err := s.endpoint.l3Conn.Read(buf)
		if err != nil {
			if hook_func.IsTerminal() {
				return
			} else {
				panic(err)
			}
		}
		log.DebugPrintf("Recv: read %d bytes", n)
		log.DebugDumpHex(buf[:n])

		packetBuffer := makeInboundPacketBuffer(buf, n)
		s.endpoint.dispatcher.DeliverNetworkPacket(header.IPv4ProtocolNumber, packetBuffer)
		packetBuffer.DecRef()
	}
}

func makeInboundPacketBuffer(buf []byte, n int) *stack.PacketBuffer {
	return stack.NewPacketBuffer(stack.PacketBufferOptions{
		Payload: buffer.MakeWithData(buf[:n]),
	})
}

// Prepare establishes the tunnel before the controller emits tunnelReady.
func (s *Stack) Prepare() error {
	s.bridgeMu.Lock()
	defer s.bridgeMu.Unlock()
	if s.bridgeClosed {
		return errors.New("stack closed")
	}
	var e error
	s.endpoint.l3Conn, e = s.endpoint.client.NewL3Conn()
	return e
}
func (s *Stack) Close() {
	s.bridgeMu.Lock()
	defer s.bridgeMu.Unlock()
	if s.bridgeClosed {
		return
	}
	s.bridgeClosed = true
	if s.endpoint.l3Conn != nil {
		_ = s.endpoint.l3Conn.Close()
	}
	s.gvisorStack.Close()
}
func (s *Stack) SetFailureHandler(f func()) { s.endpoint.onFailure = f }
